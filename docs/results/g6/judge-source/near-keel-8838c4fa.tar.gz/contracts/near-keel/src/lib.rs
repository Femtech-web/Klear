//! Keel judge on NEAR: an investor's mandate for a manager (an AI agent or a person) and a
//! manager-proof emergency exit.
//!
//! Evidence comes in only through NEAR's Read MPC: `attest` states a HyperEVM or Base log, binds
//! the MPC request to it with `expected_payload_hash`, and stores the log only if the network
//! confirms exactly that log at `Finalized`. Jobs are opened and settled by keel-core's rules
//! over stored evidence. Orders leave only as MPC signatures for this account's derived key (the
//! KeelLeg controller), and the reward leaves only as a transfer to the job's agent, once.

use keel_core::engine::{Outcome, Strategy};
use keel_core::evidence::{Chain, Log};
use keel_core::readmpc::{self, EvmLog};
use near_sdk::serde_json::{self, json, Value};
use near_sdk::store::LookupMap;
use near_sdk::{env, log, near, require, AccountId, Gas, NearToken, PanicOnDefault, Promise, PromiseError};

/// Both `sign` and `verify_foreign_transaction` require at least 15 Tgas attached.
const MPC_GAS: Gas = Gas::from_tgas(30);
const CALLBACK_GAS: Gas = Gas::from_tgas(20);

#[near(contract_state)]
#[derive(PanicOnDefault)]
pub struct KeelJudge {
    owner: AccountId,
    mpc: AccountId,
    /// Derivation path of the KeelLeg controller key, e.g. "keel/1/hyperevm".
    sign_path: String,
    /// Derivation path of the spot account's key (the exit's spot-chain transaction).
    spot_path: String,
    sign_domain: u64,
    foreign_tx_domain: u64,
    /// keel-core's `Strategy`, as JSON.
    strategy: String,
    /// "chain:tx:log_index" -> keel-core `Log` JSON, for logs the MPC network confirmed.
    attested: LookupMap<String, String>,
    /// "job:nonce" -> the order, its digest and the controller's (v, r, s), for relayers.
    signatures: LookupMap<String, String>,
}

enum Act {
    Open,
    Flatten,
    Settle,
    Propose { is_buy: bool, sz: u64, limit_px: u64 },
    Sweep,
}

fn chain_of(name: &str) -> Chain {
    match name {
        "hyperevm" => Chain::HyperEvm,
        "base" => Chain::Base,
        _ => env::panic_str("chain must be hyperevm or base"),
    }
}

fn key_of(l: &Log) -> String {
    let chain = if l.chain == Chain::HyperEvm { "hyperevm" } else { "base" };
    format!("{chain}:{}:{}", l.tx.hex(), l.log_index)
}

#[near]
impl KeelJudge {
    /// The attached deposit is the reward pool.
    #[init]
    #[payable]
    pub fn new(
        owner: AccountId,
        mpc: AccountId,
        sign_path: String,
        sign_domain: u64,
        foreign_tx_domain: u64,
        config: Value,
        spot_path: Option<String>,
    ) -> Self {
        let config = serde_json::from_value(config).unwrap_or_else(|e| env::panic_str(&format!("config: {e}")));
        let strategy = Strategy::new(config, env::attached_deposit().as_yoctonear())
            .unwrap_or_else(|e| env::panic_str(&e.code()));
        Self {
            owner,
            mpc,
            sign_path,
            spot_path: spot_path.unwrap_or_else(|| "keel/1/spot".into()),
            sign_domain,
            foreign_tx_domain,
            strategy: serde_json::to_string(&strategy).unwrap(),
            attested: LookupMap::new(b"a"),
            signatures: LookupMap::new(b"s"),
        }
    }

    // ---------- evidence ----------

    /// Anyone: ask Read MPC to confirm `log` (an `eth_getTransactionReceipt` log object) on `chain`.
    #[payable]
    pub fn attest(&mut self, chain: String, log: Value) -> Promise {
        require!(env::attached_deposit() >= NearToken::from_yoctonear(1), "attach 1 yoctoNEAR");
        let chain = chain_of(&chain);
        let evm = EvmLog::from_rpc(&log).unwrap_or_else(|e| env::panic_str(&e));
        let evidence = evm.to_evidence(chain).unwrap_or_else(|e| env::panic_str(&e));
        let key = key_of(&evidence);
        require!(!self.attested.contains_key(&key), "already attested");
        let (expected, args) = readmpc::log_request(chain, &evm, self.foreign_tx_domain);
        Promise::new(self.mpc.clone())
            .function_call("verify_foreign_transaction", args.to_string().into_bytes(), NearToken::from_yoctonear(1), MPC_GAS)
            .then(Self::ext(env::current_account_id()).with_static_gas(CALLBACK_GAS).on_attested(
                key,
                serde_json::to_string(&evidence).unwrap(),
                hex::encode(expected),
            ))
    }

    #[private]
    pub fn on_attested(&mut self, key: String, evidence: String, expected: String, #[callback_result] result: Result<Value, PromiseError>) -> bool {
        match result {
            Ok(v) if v["payload_hash"].as_str() == Some(expected.as_str()) => {
                log!("attested {}", key);
                self.attested.insert(key, evidence);
                true
            }
            _ => {
                log!("not attested {}", key);
                false
            }
        }
    }

    // ---------- jobs ----------

    /// Any agent: open a repair job from attested evidence. The caller is the job's agent.
    pub fn open_repair(&mut self, perp: String, spot: String) -> Value {
        self.act(Act::Open, perp, spot)
    }

    /// Any agent, once the owner asked for it or repair is exhausted.
    pub fn open_flatten(&mut self, perp: String, spot: String) -> Value {
        self.act(Act::Flatten, perp, spot)
    }

    /// Anyone: settle the open job on attested evidence; pays its agent once on success.
    pub fn settle(&mut self, perp: String, spot: String) -> Value {
        self.act(Act::Settle, perp, spot)
    }

    /// The mandate's manager only: one order, signed only if it fits the mandate on attested state.
    pub fn propose_order(&mut self, perp: String, spot: String, is_buy: bool, sz: u64, limit_px: u64) -> Value {
        self.act(Act::Propose { is_buy, sz, limit_px }, perp, spot)
    }

    /// Anyone, after an exit: KeelLeg's remaining USDC to its fixed payout.
    pub fn sweep(&mut self, perp: String, spot: String) -> Value {
        self.act(Act::Sweep, perp, spot)
    }

    pub fn request_flatten(&mut self) {
        require!(env::predecessor_account_id() == self.owner, "owner only");
        let mut s = self.load();
        s.request_flatten();
        self.strategy = serde_json::to_string(&s).unwrap();
    }

    fn act(&mut self, act: Act, perp: String, spot: String) -> Value {
        let mut s = self.load();
        let (perp, spot) = (self.evidence(&perp), self.evidence(&spot));
        let now = env::block_timestamp() / 1_000_000_000;
        let caller = env::predecessor_account_id();
        let r = match act {
            Act::Open => s.open_repair(now, caller.as_str(), &perp, &spot),
            Act::Flatten => s.open_flatten(now, caller.as_str(), &perp, &spot),
            Act::Settle => s.settle(now, &perp, &spot),
            Act::Propose { is_buy, sz, limit_px } => s.propose(now, caller.as_str(), &perp, &spot, is_buy, sz, limit_px),
            Act::Sweep => s.sweep(now, &perp, &spot),
        };
        // A refusal changes nothing: the transaction fails with keel-core's code.
        let out = r.unwrap_or_else(|e| env::panic_str(&e.code()));
        self.strategy = serde_json::to_string(&s).unwrap();
        match &out {
            Outcome::Sign { job_id, order, digest, spot_exit, .. } => {
                self.request_signature(self.sign_path.clone(), &digest.0, format!("{job_id}:{}", order.nonce), json!({ "order": order }));
                if let Some(x) = spot_exit {
                    self.request_signature(self.spot_path.clone(), &x.digest.0, format!("spot:{}", x.tx.nonce), json!({ "tx": x.tx }));
                }
            }
            Outcome::SignSpot { spot_exit: x, .. } => {
                self.request_signature(self.spot_path.clone(), &x.digest.0, format!("spot:{}", x.tx.nonce), json!({ "tx": x.tx }));
            }
            Outcome::SignSweep { sweep } => {
                self.request_signature(self.sign_path.clone(), &sweep.digest.0, format!("sweep:{}", sweep.sweep.nonce), json!({ "sweep": sweep.sweep }));
            }
            Outcome::Repaired { payout, .. } | Outcome::Flattened { payout, .. } => {
                let to: AccountId = payout.agent.parse().unwrap_or_else(|_| env::panic_str("agent"));
                Promise::new(to).transfer(NearToken::from_yoctonear(payout.amount));
            }
            _ => {}
        }
        let v = serde_json::to_value(&out).unwrap();
        log!("{}", v);
        v
    }

    /// Ask the MPC to sign `digest` with this account's key for `path`; the signature is stored under
    /// `key` with `record`, for anyone to relay.
    fn request_signature(&self, path: String, digest: &[u8; 32], key: String, record: Value) {
        Promise::new(self.mpc.clone())
            .function_call(
                "sign",
                keel_core::mpc::sign_args(&path, digest, self.sign_domain).to_string().into_bytes(),
                NearToken::from_yoctonear(1),
                MPC_GAS,
            )
            .then(Self::ext(env::current_account_id()).with_static_gas(CALLBACK_GAS).on_signed(key, record, hex::encode(digest)));
    }

    #[private]
    pub fn on_signed(&mut self, key: String, record: Value, digest: String, #[callback_result] result: Result<Value, PromiseError>) -> bool {
        let Ok(resp) = result else {
            log!("sign failed for {}", key);
            return false;
        };
        let Ok((v, r, s)) = keel_core::mpc::vrs(&resp) else {
            log!("unexpected signature for {}", key);
            return false;
        };
        let mut record = record;
        record["digest"] = json!(format!("0x{digest}"));
        record["v"] = json!(v);
        record["r"] = json!(format!("0x{}", hex::encode(r)));
        record["s"] = json!(format!("0x{}", hex::encode(s)));
        log!("signed {}", key);
        self.signatures.insert(key, record.to_string());
        true
    }

    // ---------- views ----------

    pub fn get_strategy(&self) -> Value {
        serde_json::from_str(&self.strategy).unwrap()
    }

    pub fn get_attested(&self, key: String) -> Option<Value> {
        self.attested.get(&key).map(|e| serde_json::from_str(e).unwrap())
    }

    pub fn get_signature(&self, job_id: u64, nonce: u64) -> Option<Value> {
        self.get_record(format!("{job_id}:{nonce}"))
    }

    /// "job:nonce" for orders (job 0 = the manager's), "spot:n" for exit transactions, "sweep:n".
    pub fn get_record(&self, key: String) -> Option<Value> {
        self.signatures.get(&key).map(|e| serde_json::from_str(e).unwrap())
    }

    pub fn get_config(&self) -> Value {
        json!({
            "owner": self.owner,
            "mpc": self.mpc,
            "sign_path": self.sign_path,
            "spot_path": self.spot_path,
            "sign_domain": self.sign_domain,
            "foreign_tx_domain": self.foreign_tx_domain,
        })
    }

    fn load(&self) -> Strategy {
        serde_json::from_str(&self.strategy).unwrap()
    }

    fn evidence(&self, key: &str) -> Log {
        let raw = self.attested.get(key).unwrap_or_else(|| env::panic_str(&format!("not attested: {key}")));
        serde_json::from_str(raw).unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use near_sdk::test_utils::VMContextBuilder;
    use near_sdk::testing_env;

    fn config() -> Value {
        json!({"strategy_id":1,"chain_id":998,"leg":"0x1111111111111111111111111111111111111111",
          "spot_account":"0x2222222222222222222222222222222222222222","spot_token":"0x3333333333333333333333333333333333333333",
          "probe":"0x4444444444444444444444444444444444444444","spot_chain":"hyperevm",
          "policy":{"perp":4,"sz_decimals":4,"band_bp":100,"max_basis_bp":500,"fee_bp":5,"max_order_sz":1000000,
            "tolerance":100000,"max_loss_usd6":2000000,"settle_delay_l1":300,"max_evidence_age_s":900,"order_ttl_s":300,
            "job_ttl_s":7200,"max_failed_attempts":3,"dust":10000,
            "repair_reward":"500000000000000000000000","flatten_reward":"500000000000000000000000"}})
    }

    fn judge() -> KeelJudge {
        let mut ctx = VMContextBuilder::new();
        ctx.attached_deposit(NearToken::from_near(1));
        testing_env!(ctx.build());
        KeelJudge::new("owner.testnet".parse().unwrap(), "v1.signer-prod.testnet".parse().unwrap(), "keel/1/hyperevm".into(), 0, 3, config(), None)
    }

    #[test]
    fn init_deposit_is_the_reward_pool() {
        let j = judge();
        let s = j.get_strategy();
        assert_eq!(s["mode"], "active");
        assert_eq!(s["pool"], "1000000000000000000000000");
        assert_eq!(j.get_config()["sign_path"], "keel/1/hyperevm");
    }

    #[test]
    #[should_panic(expected = "not attested")]
    fn jobs_use_only_attested_evidence() {
        let mut j = judge();
        j.open_repair("hyperevm:0x01:0".into(), "hyperevm:0x02:0".into());
    }

    #[test]
    #[should_panic(expected = "owner only")]
    fn only_the_owner_requests_a_flatten() {
        let mut j = judge();
        let mut ctx = VMContextBuilder::new();
        ctx.predecessor_account_id("stranger.testnet".parse().unwrap());
        testing_env!(ctx.build());
        j.request_flatten();
    }

    #[test]
    #[should_panic(expected = "chain must be hyperevm or base")]
    fn attest_rejects_unknown_chains() {
        let mut j = judge();
        let mut ctx = VMContextBuilder::new();
        ctx.attached_deposit(NearToken::from_yoctonear(1));
        testing_env!(ctx.build());
        j.attest("ethereum".into(), json!({}));
    }
}
