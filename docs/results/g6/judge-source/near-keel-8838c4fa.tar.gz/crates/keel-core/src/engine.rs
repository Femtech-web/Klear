//! Strategy state machine: a manager's mandate, repair jobs, exit (flatten) jobs, settlement and
//! rewards.
//!
//! Sizes are in CoreWriter units (1e8 = one unit of the base asset). The hedge is a short:
//! target `szi` = -spot. `delta` = spot + perp; positive means under-hedged.
//!
//! The mandate: a named manager (an AI agent or a person) may only *propose* orders; each is signed
//! only within the size, price band and leverage the investor set, and never while equity is below
//! the investor's floor. Below the floor anyone may open an exit, which moves both legs to the
//! investor's fixed addresses; no key exists that could block it.

use crate::eip712::{order_digest, sweep_digest, Order, Sweep};
use crate::spot::SpotTx;
use crate::evidence::{decode_balance, decode_snapshot, Chain, Log, PerpSnapshot, SpotBalance};
use crate::px::{lot, oracle_1e8, round_px, E8};
use crate::{keccak, Address, Bytes, Error, B32};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Policy {
    pub perp: u32,
    pub sz_decimals: u8,
    /// KeelLeg rejects any limit outside the mark +- band at execution. Planned limits sit at half
    /// the band, so normal price drift between planning and relaying does not void the order.
    pub band_bp: u16,
    /// No order is planned while |mark - oracle| exceeds this share of the oracle (KeelLeg enforces
    /// its own cap at execution).
    pub max_basis_bp: u16,
    pub fee_bp: u16,
    pub max_order_sz: u64,
    /// |delta| above this is a broken hedge; at or below it a repair succeeded.
    pub tolerance: u64,
    /// Worst-case cost of one job (slippage to the band edge plus fees), USD x 1e6.
    pub max_loss_usd6: u64,
    /// HyperCore blocks after the last queued order before a snapshot counts as settled.
    pub settle_delay_l1: u64,
    pub max_evidence_age_s: u64,
    /// Perp snapshots are planned on, so they must be younger than this (0 = `max_evidence_age_s`).
    /// Spot evidence keeps the longer limit: Base takes ~20 min to finalize.
    #[serde(default)]
    pub max_perp_age_s: u64,
    pub order_ttl_s: u64,
    pub job_ttl_s: u64,
    /// Executed attempts that leave the hedge broken before repair is declared exhausted.
    pub max_failed_attempts: u32,
    /// A flatten succeeds when both legs are at or below this size.
    pub dust: u64,
    #[serde(with = "crate::dec")]
    pub repair_reward: u128,
    #[serde(with = "crate::dec")]
    pub flatten_reward: u128,
    /// The manager's ceiling: |perp notional| / total equity after the order, in bp. 0 = no manager.
    #[serde(default)]
    pub max_leverage_bp: u32,
    /// Total equity (perp account value + spot at the oracle) below this unlocks the exit, USD x 1e6.
    /// 0 = no floor.
    #[serde(default)]
    pub equity_floor_usd6: u64,
    /// Whether a broken hedge may be repaired (off for a directional manager's mandate).
    #[serde(default = "yes")]
    pub hedge: bool,
    /// Fee settings for the exit's spot-chain transaction.
    #[serde(default)]
    pub spot_gas: u64,
    #[serde(default)]
    pub spot_max_fee_wei: u64,
    #[serde(default)]
    pub spot_priority_fee_wei: u64,
}

fn yes() -> bool {
    true
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Config {
    pub strategy_id: u64,
    pub chain_id: u64,
    pub leg: Address,
    pub spot_account: Address,
    pub spot_token: Address,
    pub probe: Address,
    /// Chain of the spot leg's `Balance` evidence.
    #[serde(default = "default_spot_chain")]
    pub spot_chain: Chain,
    /// EIP-155 chain id of the spot chain, for the exit's transaction.
    #[serde(default)]
    pub spot_chain_id: u64,
    /// NEAR account allowed to propose orders.
    #[serde(default)]
    pub manager: Option<String>,
    /// Where an exit sends the spot leg (KeelLeg's immutable `payout` receives the perp leg's USDC).
    #[serde(default)]
    pub investor: Option<Address>,
    pub policy: Policy,
}

fn default_spot_chain() -> Chain {
    Chain::Base
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Mode {
    Active,
    Repairing,
    RepairExhausted,
    Flattening,
    Flattened,
    Frozen,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum JobKind {
    Repair,
    Flatten,
}

/// Instruction for the Base half of a flatten: sell the spot leg for at least `min_out_usd6`.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SpotSell {
    #[serde(with = "crate::dec")]
    pub amount_wei: u128,
    pub min_out_usd6: u64,
}

/// The exit's spot-chain transaction (spot token to the investor) and the hash the MPC signs.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SpotExit {
    pub tx: SpotTx,
    pub digest: B32,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SweepPlan {
    pub sweep: Sweep,
    pub digest: B32,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Attempt {
    pub order: Order,
    pub digest: B32,
    pub signed_at: u64,
    pub pre_szi_1e8: i128,
    pub pre_entry_ntl: u64,
    pub worst_loss_usd6: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Job {
    pub id: u64,
    pub kind: JobKind,
    pub agent: String,
    pub opened_at: u64,
    pub expires_at: u64,
    #[serde(with = "crate::dec")]
    pub pre_spot_wei: u128,
    pub signed: u32,
    pub failed: u32,
    pub loss_used_usd6: u64,
    /// The perp order in flight; None when the job only waits on the spot leg.
    pub attempt: Option<Attempt>,
    /// Whether this job signed the exit's spot transaction.
    #[serde(default)]
    pub spot_signed: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Payout {
    pub job_id: u64,
    pub agent: String,
    #[serde(with = "crate::dec")]
    pub amount: u128,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Strategy {
    pub config: Config,
    pub mode: Mode,
    /// KeelLeg's nonce as last proven by evidence.
    pub nonce: u64,
    /// Unreserved reward funds.
    #[serde(with = "crate::dec")]
    pub pool: u128,
    pub next_job_id: u64,
    pub job: Option<Job>,
    pub owner_flatten: bool,
    pub frozen_reason: Option<String>,
    pub used: BTreeSet<(Chain, B32, u64)>,
    pub payouts: Vec<Payout>,
    /// The manager's order in flight.
    #[serde(default)]
    pub pending: Option<Attempt>,
    /// Next nonce of the spot account (only the judge ever signs for it).
    #[serde(default)]
    pub spot_nonce: u64,
    /// A sweep in flight: (KeelLeg nonce, deadline).
    #[serde(default)]
    pub pending_sweep: Option<(u64, u64)>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(tag = "outcome", rename_all = "kebab-case")]
pub enum Outcome {
    /// Ask the MPC to sign `digest`; anyone may then relay the order to KeelLeg.
    Sign { job_id: u64, order: Order, digest: B32, spot_sell: Option<SpotSell>, spot_exit: Option<SpotExit> },
    /// An exit whose perp leg is flat: only the spot transaction remains to be signed and sent.
    SignSpot { job_id: u64, spot_exit: SpotExit },
    /// After an exit: KeelLeg's remaining USDC to its fixed payout.
    SignSweep { sweep: SweepPlan },
    /// An exit without a configured investor address: the spot leg must be moved off-protocol.
    AwaitSpot { job_id: u64, spot_sell: Option<SpotSell> },
    Repaired { job_id: u64, payout: Payout },
    Flattened { job_id: u64, payout: Payout },
    /// The job ended unpaid; the strategy is open for a new job.
    Voided { job_id: u64, reason: String },
    /// Repair failed within its bounds; flattening is now allowed.
    Exhausted { job_id: u64, reason: String },
    /// The leg did something no signed order allows. Nothing more is signed.
    Frozen { reason: String },
}

struct Evidence {
    perp: PerpSnapshot,
    spot: SpotBalance,
    ids: [(Chain, B32, u64); 2],
}

impl Strategy {
    pub fn new(config: Config, pool: u128) -> Result<Self, Error> {
        let p = &config.policy;
        if p.sz_decimals > 6 || p.band_bp == 0 || p.band_bp >= 10_000 {
            return Err(Error::BadPolicy("band-or-decimals"));
        }
        if p.tolerance < lot(p.sz_decimals) || p.dust < lot(p.sz_decimals) {
            return Err(Error::BadPolicy("tolerance-below-lot"));
        }
        if p.max_order_sz < lot(p.sz_decimals) || p.max_failed_attempts == 0 || p.settle_delay_l1 == 0 {
            return Err(Error::BadPolicy("limits"));
        }
        Ok(Self {
            config,
            mode: Mode::Active,
            nonce: 0,
            pool,
            next_job_id: 1,
            job: None,
            owner_flatten: false,
            frozen_reason: None,
            used: BTreeSet::new(),
            payouts: Vec::new(),
            pending: None,
            spot_nonce: 0,
            pending_sweep: None,
        })
    }

    fn policy(&self) -> &Policy {
        &self.config.policy
    }

    fn reward(&self, kind: JobKind) -> u128 {
        match kind {
            JobKind::Repair => self.policy().repair_reward,
            JobKind::Flatten => self.policy().flatten_reward,
        }
    }

    /// Owner instruction; with an exhausted repair, the only ways to unlock flattening.
    pub fn request_flatten(&mut self) {
        self.owner_flatten = true;
    }

    fn flatten_allowed(&self, ev: &Evidence) -> bool {
        self.owner_flatten || matches!(self.mode, Mode::RepairExhausted | Mode::Flattening) || self.below_floor(ev)
    }

    /// Perp account value plus the spot leg at the oracle, USD x 1e6.
    fn equity_usd6(&self, ev: &Evidence) -> i128 {
        let oracle = oracle_1e8(ev.perp.oracle_raw, self.policy().sz_decimals).unwrap_or(0) as i128;
        ev.perp.account_value as i128 + ev.spot.balance as i128 * oracle / 10i128.pow(18) / 100
    }

    fn below_floor(&self, ev: &Evidence) -> bool {
        let floor = self.policy().equity_floor_usd6;
        floor > 0 && self.equity_usd6(ev) < floor as i128
    }

    // ---------- evidence ----------

    /// `reuse_spot`: a balance reading stays valid until the judge itself moves the spot leg, so a
    /// manager's proposals may cite one already used (it still has to be fresh).
    fn evidence(&self, now: u64, perp: &Log, spot: &Log, reuse_spot: bool) -> Result<Evidence, Error> {
        let c = &self.config;
        let ids = [perp.id(), spot.id()];
        if self.used.contains(&ids[0]) || (!reuse_spot && self.used.contains(&ids[1])) || ids[0] == ids[1] {
            return Err(Error::EvidenceReused);
        }
        if perp.emitter != c.leg || spot.emitter != c.probe {
            return Err(Error::BadEvidence("emitter"));
        }
        let s = decode_snapshot(perp)?;
        let b = decode_balance(spot, c.spot_chain)?;
        if s.account != c.leg || s.perp != c.policy.perp {
            return Err(Error::BadEvidence("snapshot-account"));
        }
        if b.account != c.spot_account || b.token != c.spot_token {
            return Err(Error::BadEvidence("balance-account"));
        }
        let fresh = |ts: u64, age: u64| ts + age >= now && ts <= now + 60;
        let perp_age = match c.policy.max_perp_age_s {
            0 => c.policy.max_evidence_age_s,
            a => a,
        };
        if !fresh(s.timestamp, perp_age) || !fresh(b.timestamp, c.policy.max_evidence_age_s) || s.last_nonce < self.nonce {
            return Err(Error::StaleEvidence);
        }
        Ok(Evidence { perp: s, spot: b, ids })
    }

    fn settled(&self, s: &PerpSnapshot) -> bool {
        s.last_nonce == 0 || s.l1_block >= s.last_queued_l1 + self.policy().settle_delay_l1
    }

    fn spot_1e8(&self, wei: u128) -> i128 {
        (wei / 10u128.pow(10)) as i128
    }

    fn perp_1e8(&self, szi: i64) -> i128 {
        szi as i128 * lot(self.policy().sz_decimals) as i128
    }

    /// Whether `s` proves that order `o` can no longer change the position, and if so whether
    /// it was executed. A never-relayed order is dead once the snapshot's time passes its deadline.
    fn resolve(&self, s: &PerpSnapshot, o: &Order) -> Result<bool, Error> {
        if s.last_nonce == o.nonce {
            return if s.timestamp > o.deadline { Ok(false) } else { Err(Error::AttemptNotResolved) };
        }
        if s.last_nonce == o.nonce + 1 {
            return if self.settled(s) { Ok(true) } else { Err(Error::SnapshotNotSettled) };
        }
        Err(Error::UnknownSignedAction)
    }

    // ---------- opening jobs ----------

    /// Any agent: open a repair job from attested state showing a broken hedge.
    pub fn open_repair(&mut self, now: u64, agent: &str, perp: &Log, spot: &Log) -> Result<Outcome, Error> {
        if self.owner_flatten || self.mode == Mode::Flattening {
            return Err(Error::FlattenInProgress);
        }
        if !self.policy().hedge {
            return Err(Error::Mandate("no-hedge-rule"));
        }
        self.open(now, agent, perp, spot, JobKind::Repair)
    }

    /// Any agent: an exit, once the owner asked for it, repair was exhausted, or attested equity is
    /// below the investor's floor.
    pub fn open_flatten(&mut self, now: u64, agent: &str, perp: &Log, spot: &Log) -> Result<Outcome, Error> {
        self.open(now, agent, perp, spot, JobKind::Flatten)
    }

    fn open(&mut self, now: u64, agent: &str, perp: &Log, spot: &Log, kind: JobKind) -> Result<Outcome, Error> {
        if matches!(self.mode, Mode::Frozen | Mode::Flattened) {
            return Err(Error::Frozen);
        }
        let ev = self.evidence(now, perp, spot, false)?;
        if kind == JobKind::Flatten && !self.flatten_allowed(&ev) {
            return Err(Error::FlattenNotTriggered);
        }
        // The manager's order in flight must be over before anything else is signed.
        let pending_resolved = match &self.pending {
            Some(p) => {
                self.resolve(&ev.perp, &p.order)?;
                true
            }
            None => false,
        };
        let mut released = 0;
        match &self.job {
            Some(job) => {
                // A flatten may pre-empt a repair; otherwise only an expired job can be replaced.
                let preempt = kind == JobKind::Flatten && job.kind == JobKind::Repair;
                if now < job.expires_at && !preempt {
                    return Err(Error::JobActive);
                }
                if let Some(a) = &job.attempt {
                    self.resolve(&ev.perp, &a.order)?;
                }
                released = self.reward(job.kind);
            }
            None if !pending_resolved => {
                if ev.perp.last_nonce != self.nonce {
                    return Err(Error::UnknownSignedAction);
                }
                if !self.settled(&ev.perp) {
                    return Err(Error::SnapshotNotSettled);
                }
            }
            None => {}
        }
        let reward = self.reward(kind);
        if self.pool + released < reward {
            return Err(Error::RewardPoolEmpty);
        }
        let mut job = Job {
            id: self.next_job_id,
            kind,
            agent: agent.to_string(),
            opened_at: now,
            expires_at: now + self.policy().job_ttl_s,
            pre_spot_wei: ev.spot.balance,
            signed: 1,
            failed: 0,
            loss_used_usd6: 0,
            attempt: None,
            spot_signed: false,
        };
        let attempt = self.plan(now, &job, &ev.perp, ev.spot.balance)?;
        let spot_left = self.spot_1e8(ev.spot.balance) > self.policy().dust as i128;
        if attempt.is_none() && (kind == JobKind::Repair || !spot_left) {
            return Err(Error::WithinTolerance);
        }
        job.loss_used_usd6 = attempt.as_ref().map_or(0, |a| a.worst_loss_usd6);
        job.attempt = attempt;

        if pending_resolved {
            self.pending = None;
        }
        self.nonce = ev.perp.last_nonce;
        self.pool = self.pool + released - reward;
        self.used.extend(ev.ids);
        self.next_job_id += 1;
        self.mode = if kind == JobKind::Repair { Mode::Repairing } else { Mode::Flattening };
        let out = self.sign_outcome(&mut job, &ev);
        self.job = Some(job);
        Ok(out)
    }

    fn sign_outcome(&self, job: &mut Job, ev: &Evidence) -> Outcome {
        let p = self.policy();
        let spot_left = job.kind == JobKind::Flatten && self.spot_1e8(ev.spot.balance) > p.dust as i128;
        // With an investor address configured the exit moves the spot leg there itself.
        let spot_exit = match (&self.config.investor, spot_left && p.spot_gas > 0) {
            (Some(investor), true) => {
                let tx = SpotTx::erc20_transfer(
                    self.config.spot_chain_id,
                    self.spot_nonce,
                    p.spot_priority_fee_wei,
                    p.spot_max_fee_wei,
                    p.spot_gas,
                    self.config.spot_token,
                    investor,
                    ev.spot.balance,
                );
                job.spot_signed = true;
                Some(SpotExit { digest: Bytes(tx.signing_hash()), tx })
            }
            _ => None,
        };
        let spot_sell = (spot_left && spot_exit.is_none())
            .then(|| {
                let p = self.policy();
                let oracle = oracle_1e8(ev.perp.oracle_raw, p.sz_decimals).unwrap_or(0) as u128;
                let ntl_usd6 = self.spot_1e8(ev.spot.balance) as u128 * oracle / E8 as u128 / 100;
                SpotSell {
                    amount_wei: ev.spot.balance,
                    min_out_usd6: (ntl_usd6 * (10_000 - p.band_bp as u128) / 10_000) as u64,
                }
            });
        match (&job.attempt, spot_exit) {
            (Some(a), spot_exit) => Outcome::Sign { job_id: job.id, order: a.order.clone(), digest: a.digest, spot_sell, spot_exit },
            (None, Some(spot_exit)) => Outcome::SignSpot { job_id: job.id, spot_exit },
            (None, None) => Outcome::AwaitSpot { job_id: job.id, spot_sell },
        }
    }

    /// The one order the attested state calls for, or None if the job has nothing left to do on
    /// the perp leg. The agent chooses nothing: size is capped by the per-order cap and the job's
    /// remaining loss budget (charged at the full band), and the limit sits at half the band around
    /// the snapshot's oracle.
    fn plan(&self, now: u64, job: &Job, s: &PerpSnapshot, spot_wei: u128) -> Result<Option<Attempt>, Error> {
        let p = self.policy();
        let spot = self.spot_1e8(spot_wei);
        let perp = self.perp_1e8(s.szi);
        let (is_buy, reduce_only, need) = match job.kind {
            JobKind::Repair => {
                if perp > 0 {
                    return Err(Error::UnexpectedLong);
                }
                let delta = spot + perp;
                if delta.unsigned_abs() <= p.tolerance as u128 {
                    return Ok(None);
                }
                if delta > 0 {
                    (false, false, delta as u128)
                } else {
                    (true, true, delta.unsigned_abs())
                }
            }
            JobKind::Flatten => {
                if perp.unsigned_abs() <= p.dust as u128 {
                    return Ok(None);
                }
                (perp < 0, true, perp.unsigned_abs())
            }
        };
        let oracle = oracle_1e8(s.oracle_raw, p.sz_decimals).filter(|o| *o > 0).ok_or(Error::BadPrice)?;
        let mark = oracle_1e8(s.mark_raw, p.sz_decimals).filter(|m| *m > 0).ok_or(Error::BadPrice)?;
        // Basis in bp of the oracle, rounded up; it is charged to the loss budget with the band.
        let basis_bp = ((oracle.abs_diff(mark) as u128 * 10_000).div_ceil(oracle as u128)) as u64;
        if basis_bp > p.max_basis_bp as u64 {
            return Err(Error::MarketDislocated);
        }
        let cost_bp = (p.band_bp as u64 + p.fee_bp as u64 + basis_bp) as u128;
        let budget = p.max_loss_usd6.saturating_sub(job.loss_used_usd6) as u128;
        // worst_usd6(sz) = sz * oracle / 1e8 / 100 * cost_bp / 1e4, solved for sz.
        let by_loss = budget * 100 * E8 as u128 * 10_000 / (mark.max(oracle) as u128 * cost_bp);
        let l = lot(p.sz_decimals) as u128;
        let sz = need.min(p.max_order_sz as u128).min(by_loss) / l * l;
        if sz == 0 {
            return Err(Error::LossBudgetExhausted);
        }
        let offset = p.band_bp as u64 / 2;
        let limit_px = if is_buy {
            round_px(mark * (10_000 + offset) / 10_000, p.sz_decimals, false)
        } else {
            round_px(mark * (10_000 - offset) / 10_000, p.sz_decimals, true)
        }
        .ok_or(Error::BadPrice)?;
        let worst = sz * mark.max(oracle) as u128 / E8 as u128 * cost_bp / 100 / 10_000;

        let nonce = s.last_nonce;
        let mut seed = b"keel/cloid".to_vec();
        seed.extend_from_slice(&self.config.strategy_id.to_be_bytes());
        seed.extend_from_slice(&job.id.to_be_bytes());
        seed.extend_from_slice(&nonce.to_be_bytes());
        let cloid = u128::from_be_bytes(keccak(&seed)[..16].try_into().unwrap()).max(1);
        let order = Order { nonce, is_buy, limit_px, sz: sz as u64, reduce_only, cloid, deadline: now + p.order_ttl_s };
        let digest = Bytes(order_digest(self.config.chain_id, &self.config.leg, &order));
        Ok(Some(Attempt {
            order,
            digest,
            signed_at: now,
            pre_szi_1e8: perp,
            pre_entry_ntl: s.entry_ntl,
            worst_loss_usd6: worst as u64,
        }))
    }

    // ---------- settlement ----------

    /// Anyone: present a settled snapshot and a spot balance read after the attempt was signed.
    /// Pays the job's agent once if the job's own success condition holds; otherwise signs the
    /// next attempt or ends the job.
    pub fn settle(&mut self, now: u64, perp: &Log, spot: &Log) -> Result<Outcome, Error> {
        if self.mode == Mode::Frozen {
            return Err(Error::Frozen);
        }
        let mut job = self.job.clone().ok_or(Error::NoOpenJob)?;
        let a = job.attempt.clone();
        let ev = self.evidence(now, perp, spot, false)?;
        let executed = match &a {
            Some(a) => self.resolve(&ev.perp, &a.order)?,
            None if ev.perp.last_nonce == self.nonce => false,
            None => return Err(Error::UnknownSignedAction),
        };
        if ev.spot.timestamp < a.as_ref().map_or(job.opened_at, |a| a.signed_at) {
            return Err(Error::StaleEvidence);
        }
        let p = self.policy().clone();
        let spot = self.spot_1e8(ev.spot.balance);
        let post = self.perp_1e8(ev.perp.szi);

        // The evidence is consumed from here on; every branch changes state.
        self.used.extend(ev.ids);
        self.nonce = ev.perp.last_nonce;

        if let Some(a) = &a {
            if let Some(out) = self.check_execution(&job, a, &ev.perp, post, executed) {
                return Ok(out);
            }
        }

        match job.kind {
            JobKind::Repair => {
                if ev.spot.balance != job.pre_spot_wei {
                    return Ok(self.void(job.id, "spot-leg-changed"));
                }
                let pre = a.as_ref().map_or(post, |a| a.pre_szi_1e8);
                let delta = spot + post;
                let overshot = if spot + pre > 0 { delta < -(p.tolerance as i128) } else { delta > p.tolerance as i128 };
                if overshot {
                    return Ok(self.freeze("repair-overshot-target"));
                }
                if delta.unsigned_abs() <= p.tolerance as u128 {
                    return Ok(self.pay(&job, Mode::Active));
                }
            }
            JobKind::Flatten => {
                if post.unsigned_abs() <= p.dust as u128 && spot.unsigned_abs() <= p.dust as u128 {
                    if job.spot_signed {
                        self.spot_nonce += 1;
                    }
                    return Ok(self.pay(&job, Mode::Flattened));
                }
            }
        }

        // Not done yet. An exit whose perp leg is flat is only waiting on the spot leg.
        let perp_done = job.kind == JobKind::Flatten && post.unsigned_abs() <= p.dust as u128;
        if executed && !perp_done {
            job.failed += 1;
        } else if let (false, Some(a)) = (executed, &a) {
            // The order expired without being relayed and never cost anything.
            job.loss_used_usd6 = job.loss_used_usd6.saturating_sub(a.worst_loss_usd6);
        }
        if job.failed >= p.max_failed_attempts {
            return Ok(self.exhaust(&job, "attempts"));
        }
        if now >= job.expires_at {
            return Ok(self.void(job.id, "job-expired"));
        }
        match self.plan(now, &job, &ev.perp, ev.spot.balance) {
            Ok(next) => {
                if let Some(n) = &next {
                    job.signed += 1;
                    job.loss_used_usd6 += n.worst_loss_usd6;
                }
                job.attempt = next;
                let out = self.sign_outcome(&mut job, &ev);
                self.job = Some(job);
                Ok(out)
            }
            Err(Error::LossBudgetExhausted) => Ok(self.exhaust(&job, "loss-budget")),
            // Not the job's fault and not permanent: end it unpaid; a new job can open later.
            Err(Error::MarketDislocated) => Ok(self.void(job.id, "market-dislocated")),
            Err(e) => Ok(self.freeze(&e.code())),
        }
    }

    // ---------- the manager's mandate ----------

    /// The manager proposes one order. It is signed only if, on attested state: equity is at or
    /// above the floor, the market is not dislocated, the size and price fit the bounds, and the
    /// post-trade leverage is within the mandate (orders that only reduce exposure always pass).
    #[allow(clippy::too_many_arguments)]
    pub fn propose(&mut self, now: u64, caller: &str, perp: &Log, spot: &Log, is_buy: bool, sz: u64, limit_px: u64) -> Result<Outcome, Error> {
        let manager = self.config.manager.as_deref().ok_or(Error::Mandate("no-manager"))?;
        if caller != manager {
            return Err(Error::Mandate("not-the-manager"));
        }
        if self.mode != Mode::Active || self.job.is_some() || self.owner_flatten {
            return Err(Error::Mandate("strategy-not-active"));
        }
        let ev = self.evidence(now, perp, spot, true)?;
        match &self.pending {
            Some(p) => {
                self.resolve(&ev.perp, &p.order)?;
            }
            None => {
                if ev.perp.last_nonce != self.nonce {
                    return Err(Error::UnknownSignedAction);
                }
                if !self.settled(&ev.perp) {
                    return Err(Error::SnapshotNotSettled);
                }
            }
        }
        let p = self.policy();
        let oracle = oracle_1e8(ev.perp.oracle_raw, p.sz_decimals).filter(|o| *o > 0).ok_or(Error::BadPrice)?;
        let mark = oracle_1e8(ev.perp.mark_raw, p.sz_decimals).filter(|m| *m > 0).ok_or(Error::BadPrice)?;
        if (oracle.abs_diff(mark) as u128 * 10_000).div_ceil(oracle as u128) > p.max_basis_bp as u128 {
            return Err(Error::MarketDislocated);
        }
        let equity = self.equity_usd6(&ev);
        if self.below_floor(&ev) {
            return Err(Error::Mandate("equity-below-floor"));
        }
        let l = lot(p.sz_decimals);
        if sz == 0 || sz > p.max_order_sz || sz % l != 0 {
            return Err(Error::Mandate("size"));
        }
        if !crate::px::valid_px(limit_px, p.sz_decimals) || limit_px.abs_diff(mark) as u128 * 10_000 > mark as u128 * p.band_bp as u128 {
            return Err(Error::Mandate("price-outside-band"));
        }
        let cur = self.perp_1e8(ev.perp.szi);
        let next = if is_buy { cur + sz as i128 } else { cur - sz as i128 };
        let reduces = next.unsigned_abs() < cur.unsigned_abs() && next.signum() * cur.signum() >= 0;
        if !reduces {
            let notional_usd6 = next.unsigned_abs() * mark as u128 / E8 as u128 / 100;
            if equity <= 0 || notional_usd6 * 10_000 > equity as u128 * p.max_leverage_bp as u128 {
                return Err(Error::Mandate("leverage"));
            }
        }
        let nonce = ev.perp.last_nonce;
        let mut seed = b"keel/manager".to_vec();
        seed.extend_from_slice(&self.config.strategy_id.to_be_bytes());
        seed.extend_from_slice(&nonce.to_be_bytes());
        let cloid = u128::from_be_bytes(keccak(&seed)[..16].try_into().unwrap()).max(1);
        let order = Order { nonce, is_buy, limit_px, sz, reduce_only: reduces, cloid, deadline: now + p.order_ttl_s };
        let digest = Bytes(order_digest(self.config.chain_id, &self.config.leg, &order));
        self.pending = Some(Attempt { order: order.clone(), digest, signed_at: now, pre_szi_1e8: cur, pre_entry_ntl: ev.perp.entry_ntl, worst_loss_usd6: 0 });
        self.nonce = nonce;
        self.used.insert(ev.ids[0]);
        Ok(Outcome::Sign { job_id: 0, order, digest, spot_sell: None, spot_exit: None })
    }

    /// Anyone, after an exit: KeelLeg's remaining USDC goes to its fixed payout (the investor).
    pub fn sweep(&mut self, now: u64, perp: &Log, spot: &Log) -> Result<Outcome, Error> {
        if self.mode != Mode::Flattened {
            return Err(Error::Mandate("sweep-only-after-exit"));
        }
        let ev = self.evidence(now, perp, spot, true)?;
        match self.pending_sweep {
            Some((n, deadline)) if ev.perp.last_nonce == n && ev.perp.timestamp <= deadline => return Err(Error::AttemptNotResolved),
            Some((n, _)) if ev.perp.last_nonce == n || ev.perp.last_nonce == n + 1 => {}
            Some(_) => return Err(Error::UnknownSignedAction),
            None if ev.perp.last_nonce != self.nonce => return Err(Error::UnknownSignedAction),
            None => {}
        }
        if ev.perp.account_value <= 0 {
            return Err(Error::WithinTolerance);
        }
        let ntl = ev.perp.account_value as u64;
        let sweep = Sweep { nonce: ev.perp.last_nonce, usd_ntl: ntl, usdc_wei: ntl * 100, deadline: now + self.policy().order_ttl_s };
        let digest = Bytes(sweep_digest(self.config.chain_id, &self.config.leg, &sweep));
        self.pending_sweep = Some((sweep.nonce, sweep.deadline));
        self.nonce = ev.perp.last_nonce;
        self.used.insert(ev.ids[0]);
        Ok(Outcome::SignSweep { sweep: SweepPlan { sweep, digest } })
    }

    /// Compare the position change with the attempt's order. A change the order cannot explain
    /// in the direction of an exchange-side event (ADL, liquidation: both only shrink a position)
    /// voids the job; a change no signed order allows freezes the strategy.
    fn check_execution(&mut self, job: &Job, a: &Attempt, s: &PerpSnapshot, post: i128, executed: bool) -> Option<Outcome> {
        let o = &a.order;
        let pre = a.pre_szi_1e8;
        let moved = post - pre;
        let shrank = post.unsigned_abs() < pre.unsigned_abs() && post.signum() * pre.signum() >= 0;
        if !executed {
            return match moved {
                0 => None,
                _ if shrank => Some(self.void(job.id, "position-changed-externally")),
                _ => Some(self.freeze("position-changed-without-order")),
            };
        }
        if post.signum() * pre.signum() < 0 {
            return Some(self.freeze("position-flipped"));
        }
        let with_order = if o.is_buy { moved >= 0 } else { moved <= 0 };
        if !with_order || moved.unsigned_abs() > o.sz as u128 {
            return Some(if shrank {
                self.void(job.id, "position-changed-externally")
            } else {
                self.freeze("fill-exceeds-order")
            });
        }
        // A sell that grows a short adds exactly its fill notional to entryNtl, so the average
        // fill price is observable; it must not be below the limit (one tick of rounding).
        if !o.is_buy && moved < 0 && pre <= 0 {
            let added_usd6 = s.entry_ntl as i128 - a.pre_entry_ntl as i128;
            let avg_px = added_usd6 * 100 * E8 as i128 / -moved;
            if avg_px + 10i128.pow(2 + self.policy().sz_decimals as u32) < o.limit_px as i128 {
                return Some(self.freeze("fill-below-limit"));
            }
        }
        None
    }

    fn pay(&mut self, job: &Job, mode: Mode) -> Outcome {
        let payout = Payout { job_id: job.id, agent: job.agent.clone(), amount: self.reward(job.kind) };
        self.payouts.push(payout.clone());
        self.job = None;
        self.mode = mode;
        match job.kind {
            JobKind::Repair => Outcome::Repaired { job_id: job.id, payout },
            JobKind::Flatten => {
                self.owner_flatten = false;
                Outcome::Flattened { job_id: job.id, payout }
            }
        }
    }

    fn release(&mut self) {
        if let Some(j) = self.job.take() {
            self.pool += self.reward(j.kind);
        }
    }

    fn void(&mut self, job_id: u64, reason: &str) -> Outcome {
        let kind = self.job.as_ref().map(|j| j.kind);
        self.release();
        self.mode = if kind == Some(JobKind::Flatten) { Mode::Flattening } else { Mode::Active };
        Outcome::Voided { job_id, reason: reason.into() }
    }

    fn exhaust(&mut self, job: &Job, reason: &str) -> Outcome {
        self.release();
        self.mode = if job.kind == JobKind::Repair { Mode::RepairExhausted } else { Mode::Flattening };
        Outcome::Exhausted { job_id: job.id, reason: reason.into() }
    }

    fn freeze(&mut self, reason: &str) -> Outcome {
        self.release();
        self.mode = Mode::Frozen;
        self.frozen_reason = Some(reason.into());
        Outcome::Frozen { reason: reason.into() }
    }
}
