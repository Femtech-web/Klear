//! Judge rules on synthetic logs. These logs are encoded here, not read from any chain.

use keel_core::abi::{enc_address, enc_u128, enc_u64};
use keel_core::engine::{Config, Mode, Outcome, Policy, Strategy};
use keel_core::evidence::{Chain, Log, BALANCE_SIG, SNAPSHOT_SIG};
use keel_core::{keccak, Address, Bytes, Error};

const NOW: u64 = 1_800_000_000;
const ETH: i64 = 10_000; // szi units
const WEI: u128 = 1_000_000_000_000_000_000;
const NEAR: u128 = 1_000_000_000_000_000_000_000_000;

fn addr(b: u8) -> Address {
    Bytes([b; 20])
}

fn policy() -> Policy {
    Policy {
        perp: 4,
        sz_decimals: 4,
        band_bp: 100,
        max_basis_bp: 200,
        fee_bp: 5,
        max_order_sz: 100_000_000,
        tolerance: 1_000_000,
        max_loss_usd6: 100_000_000,
        settle_delay_l1: 10,
        max_evidence_age_s: 120,
        max_perp_age_s: 0,
        order_ttl_s: 60,
        job_ttl_s: 3_600,
        max_failed_attempts: 3,
        dust: 10_000,
        repair_reward: NEAR,
        flatten_reward: 2 * NEAR,
        max_leverage_bp: 0,
        equity_floor_usd6: 0,
        hedge: true,
        spot_gas: 0,
        spot_max_fee_wei: 0,
        spot_priority_fee_wei: 0,
    }
}

fn strategy(p: Policy) -> Strategy {
    let c = Config {
        strategy_id: 7,
        chain_id: 998,
        leg: addr(0x11),
        spot_account: addr(0x22),
        spot_token: addr(0x33),
        probe: addr(0x44),
        spot_chain: Chain::Base,
        spot_chain_id: 84532,
        manager: None,
        investor: None,
        policy: p,
    };
    Strategy::new(c, 10 * NEAR).unwrap()
}

struct World {
    szi: i64,
    entry: u64,
    oracle_raw: u64,
    mark_raw: u64,
    account_value: i64,
    l1: u64,
    nonce: u64,
    queued: u64,
    spot: u128,
    ts: u64,
    seq: u64,
}

impl World {
    fn hedged() -> Self {
        // 1 ETH spot, 1 ETH short at 3000, nothing signed yet.
        World { szi: -ETH, entry: 3_000_000_000, oracle_raw: 300_000, mark_raw: 300_000, account_value: 30_000_000, l1: 1_000, nonce: 0, queued: 0, spot: WEI, ts: NOW, seq: 0 }
    }

    fn id(&mut self) -> Bytes<32> {
        self.seq += 1;
        Bytes(keccak(&self.seq.to_be_bytes()))
    }

    fn perp(&mut self) -> Log {
        let mut d = Vec::new();
        d.extend_from_slice(&enc_u64(4));
        let mut w = [if self.szi < 0 { 0xff } else { 0 }; 32];
        w[24..].copy_from_slice(&self.szi.to_be_bytes());
        d.extend_from_slice(&w);
        for v in [self.entry, self.oracle_raw, self.mark_raw] {
            d.extend_from_slice(&enc_u64(v));
        }
        let mut av = [if self.account_value < 0 { 0xff } else { 0 }; 32];
        av[24..].copy_from_slice(&self.account_value.to_be_bytes());
        d.extend_from_slice(&av);
        for v in [self.l1, self.nonce, self.queued, 5_000, self.ts] {
            d.extend_from_slice(&enc_u64(v));
        }
        d.extend_from_slice(&[0u8; 32]);
        Log {
            chain: Chain::HyperEvm,
            tx: self.id(),
            log_index: 0,
            emitter: addr(0x11),
            topics: vec![Bytes(keccak(SNAPSHOT_SIG.as_bytes())), Bytes(enc_address(&addr(0x11).0))],
            data: d,
        }
    }

    fn spot(&mut self) -> Log {
        let mut d = Vec::new();
        d.extend_from_slice(&enc_u128(self.spot));
        d.extend_from_slice(&enc_u64(9_000));
        d.extend_from_slice(&enc_u64(self.ts));
        d.extend_from_slice(&[0u8; 32]);
        Log {
            chain: Chain::Base,
            tx: self.id(),
            log_index: 3,
            emitter: addr(0x44),
            topics: vec![
                Bytes(keccak(BALANCE_SIG.as_bytes())),
                Bytes(enc_address(&addr(0x22).0)),
                Bytes(enc_address(&addr(0x33).0)),
            ],
            data: d,
        }
    }

    /// KeelLeg accepted the signed order: nonce advances and the order is queued.
    fn relay(&mut self) {
        self.nonce += 1;
        self.queued = self.l1;
    }

    /// HyperCore executes it and enough blocks pass for a settled snapshot.
    fn fill(&mut self, d_szi: i64, px_usd6_per_eth: u64) {
        if d_szi < 0 && self.szi <= 0 {
            self.entry += (-d_szi) as u64 * px_usd6_per_eth / ETH as u64;
        } else if self.szi != 0 {
            let abs = self.szi.unsigned_abs();
            let next = (self.szi + d_szi).unsigned_abs();
            self.entry = self.entry * next / abs;
        }
        self.szi += d_szi;
        self.advance();
    }

    fn advance(&mut self) {
        self.l1 += 20;
        self.ts += 5;
    }
}

fn sign(o: Result<Outcome, Error>) -> keel_core::eip712::Order {
    match o {
        Ok(Outcome::Sign { order, .. }) => order,
        other => panic!("expected Sign, got {other:?}"),
    }
}

/// ADL cut the short from 1.0 to 0.6 ETH: under-hedged by 0.4.
fn broken() -> (Strategy, World) {
    let s = strategy(policy());
    let mut w = World::hedged();
    w.szi = -6 * ETH / 10;
    w.entry = 1_800_000_000;
    (s, w)
}

#[test]
fn healthy_hedge_cannot_be_farmed() {
    let mut s = strategy(policy());
    let mut w = World::hedged();
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::WithinTolerance));
    assert_eq!(s.pool, 10 * NEAR);
}

#[test]
fn plan_is_bounded_and_not_chosen_by_the_agent() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    let o = sign(s.open_repair(NOW, "agent.a", &p, &b));
    assert!(!o.is_buy && !o.reduce_only);
    assert_eq!(o.sz, 40_000_000, "exactly the 0.4 ETH gap");
    assert_eq!(o.limit_px, 2985 * 100_000_000, "oracle 3000 minus half the 1% band");
    assert_eq!(o.nonce, 0);
    assert_eq!(o.deadline, NOW + 60);
    assert_eq!(s.mode, Mode::Repairing);
    assert_eq!(s.pool, 9 * NEAR, "reward reserved");
}

#[test]
fn race_second_agent_is_refused() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    let (p2, b2) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.b", &p2, &b2), Err(Error::JobActive));
}

#[test]
fn repaired_pays_exactly_once() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(-4 * ETH / 10, 2_999_000_000);
    let (p2, b2) = (w.perp(), w.spot());
    match s.settle(NOW + 10, &p2, &b2) {
        Ok(Outcome::Repaired { payout, .. }) => {
            assert_eq!(payout.agent, "agent.a");
            assert_eq!(payout.amount, NEAR);
        }
        other => panic!("{other:?}"),
    }
    assert_eq!(s.mode, Mode::Active);
    assert_eq!(s.payouts.len(), 1);

    // Claim again with the same evidence, with fresh evidence, or by reopening.
    assert_eq!(s.settle(NOW + 10, &p2, &b2), Err(Error::NoOpenJob));
    let (p3, b3) = (w.perp(), w.spot());
    assert_eq!(s.settle(NOW + 11, &p3, &b3), Err(Error::NoOpenJob));
    assert_eq!(s.open_repair(NOW + 11, "agent.a", &p2, &b2), Err(Error::EvidenceReused));
    assert_eq!(s.open_repair(NOW + 11, "agent.a", &p3, &b3), Err(Error::WithinTolerance));
    assert_eq!(s.payouts.len(), 1);
}

#[test]
fn submission_is_not_success() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));

    // Not relayed yet and deadline not passed: undecidable.
    w.ts += 5;
    let (p1, b1) = (w.perp(), w.spot());
    assert_eq!(s.settle(NOW + 5, &p1, &b1), Err(Error::AttemptNotResolved));

    // Relayed, but read before HyperCore had time to execute it.
    w.relay();
    w.l1 += 2;
    let (p2, b2) = (w.perp(), w.spot());
    assert_eq!(s.settle(NOW + 6, &p2, &b2), Err(Error::SnapshotNotSettled));
    assert_eq!(s.payouts.len(), 0);
}

#[test]
fn partial_fill_continues_then_pays_once() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(-ETH / 10, 2_999_000_000);
    let (p2, b2) = (w.perp(), w.spot());
    let o2 = sign(s.settle(NOW + 10, &p2, &b2));
    assert_eq!(o2.nonce, 1);
    assert_eq!(o2.sz, 30_000_000, "the remaining 0.3 ETH");
    assert_eq!(s.payouts.len(), 0);

    w.relay();
    w.fill(-3 * ETH / 10, 2_998_000_000);
    let (p3, b3) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 20, &p3, &b3), Ok(Outcome::Repaired { .. })));
    assert_eq!(s.payouts.len(), 1);
    assert_eq!(s.pool, 9 * NEAR);
}

#[test]
fn rejected_orders_exhaust_repair_and_unlock_flatten() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    let (pf, bf) = (w.perp(), w.spot());
    assert_eq!(s.open_flatten(NOW, "agent.f", &pf, &bf), Err(Error::FlattenNotTriggered));

    let mut out = None;
    for _ in 0..3 {
        w.relay();
        w.advance(); // executed, rejected by the exchange: no position change
        let (p2, b2) = (w.perp(), w.spot());
        out = Some(s.settle(w.ts, &p2, &b2));
    }
    assert!(matches!(out, Some(Ok(Outcome::Exhausted { .. }))), "{out:?}");
    assert_eq!(s.mode, Mode::RepairExhausted);
    assert_eq!(s.payouts.len(), 0);
    assert_eq!(s.pool, 10 * NEAR, "reservation released");

    let (p3, b3) = (w.perp(), w.spot());
    let o = sign(s.open_flatten(w.ts, "agent.f", &p3, &b3));
    assert!(o.is_buy && o.reduce_only, "flatten only ever reduces");
}

#[test]
fn unrelayed_orders_do_not_count_as_failures() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    for i in 1..=5u64 {
        w.ts = NOW + 61 * i; // past each deadline, never relayed
        let (p2, b2) = (w.perp(), w.spot());
        let o = sign(s.settle(w.ts, &p2, &b2));
        assert_eq!(o.nonce, 0, "the same nonce is re-signed");
    }
    assert_eq!(s.mode, Mode::Repairing, "a griefer cannot force flatten by not relaying");
    w.ts = NOW + 3_700;
    let (p3, b3) = (w.perp(), w.spot());
    assert!(matches!(s.settle(w.ts, &p3, &b3), Ok(Outcome::Voided { ref reason, .. }) if reason == "job-expired"));
    assert_eq!(s.mode, Mode::Active);
}

#[test]
fn closing_both_legs_is_never_a_repair() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(0, 0);
    // Delta restored by selling 0.4 ETH of spot instead of growing the short.
    w.spot = 6 * WEI / 10;
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Voided { ref reason, .. }) if reason == "spot-leg-changed"));
    assert_eq!(s.payouts.len(), 0);

    // Both legs closed to zero: delta is 0 but it is still not a repair.
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.advance();
    w.spot = 0;
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Voided { .. })));
    assert_eq!(s.payouts.len(), 0);
}

#[test]
fn exchange_side_shrink_voids_instead_of_paying() {
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(2 * ETH / 10, 0); // liquidation/ADL shrank the short during the job
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Voided { ref reason, .. }) if reason == "position-changed-externally"));
}

#[test]
fn fill_beyond_order_or_limit_freezes() {
    // Grew the short by more than ordered: no signed order explains it.
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(-5 * ETH / 10, 2_999_000_000);
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Frozen { .. })));
    assert_eq!(s.mode, Mode::Frozen);
    let (p3, b3) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW + 20, "agent.a", &p3, &b3), Err(Error::Frozen));

    // Average fill price below the signed limit (2985).
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.fill(-4 * ETH / 10, 2_900_000_000);
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Frozen { ref reason }) if reason == "fill-below-limit"));
    assert_eq!(s.payouts.len(), 0);
}

#[test]
fn loss_budget_caps_size_and_blocks_jobs_it_cannot_afford() {
    // Worst case per ETH at 3000 with 1% band + 0.05% fee: 31.5 USD. A 6.3 USD budget allows 0.2 ETH.
    let mut p = policy();
    p.max_loss_usd6 = 6_300_000;
    let mut s = strategy(p);
    let mut w = World::hedged();
    w.szi = -6 * ETH / 10;
    let (pl, bl) = (w.perp(), w.spot());
    let o = sign(s.open_repair(NOW, "agent.a", &pl, &bl));
    assert_eq!(o.sz, 20_000_000);

    let mut p = policy();
    p.max_loss_usd6 = 100;
    let mut s = strategy(p);
    let (pl, bl) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &pl, &bl), Err(Error::LossBudgetExhausted));
}

#[test]
fn over_hedged_repair_buys_reduce_only() {
    let mut s = strategy(policy());
    let mut w = World::hedged();
    w.szi = -15 * ETH / 10;
    w.entry = 4_500_000_000;
    let (p, b) = (w.perp(), w.spot());
    let o = sign(s.open_repair(NOW, "agent.a", &p, &b));
    assert!(o.is_buy && o.reduce_only);
    assert_eq!(o.sz, 50_000_000);
    assert_eq!(o.limit_px, 3015 * 100_000_000);
    w.relay();
    w.fill(5 * ETH / 10, 0);
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::Repaired { .. })));
}

#[test]
fn signatures_the_judge_did_not_issue_stop_everything() {
    let (mut s, mut w) = broken();
    w.nonce = 2; // KeelLeg executed two signed actions this strategy never issued
    w.queued = w.l1;
    w.advance();
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::UnknownSignedAction));
}

#[test]
fn evidence_must_be_fresh_from_the_right_contracts() {
    let (mut s, mut w) = broken();
    w.ts = NOW - 500;
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::StaleEvidence));

    w.ts = NOW;
    let mut p = w.perp();
    p.emitter = addr(0x99);
    let b = w.spot();
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::BadEvidence("emitter")));

    let mut p = w.perp();
    p.chain = Chain::Base;
    assert!(matches!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::BadEvidence(_))));

    let p = w.perp();
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &p.clone()), Err(Error::EvidenceReused));
}

#[test]
fn flatten_has_its_own_success_condition() {
    let (mut s, mut w) = broken();
    s.request_flatten();
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::FlattenInProgress));
    let o = match s.open_flatten(NOW, "agent.f", &p, &b) {
        Ok(Outcome::Sign { order, spot_sell: Some(sell), .. }) => {
            assert_eq!(sell.amount_wei, WEI);
            assert_eq!(sell.min_out_usd6, 2_970_000_000, "1 ETH at 3000 less the band");
            order
        }
        other => panic!("{other:?}"),
    };
    assert!(o.is_buy && o.reduce_only);
    assert_eq!(o.sz, 60_000_000);

    // Perp closed but spot still held: hedge-neutral is not flat. No payout.
    w.relay();
    w.fill(6 * ETH / 10, 0);
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(NOW + 10, &p2, &b2), Ok(Outcome::AwaitSpot { spot_sell: Some(_), .. })));
    assert_eq!(s.payouts.len(), 0);

    // The Base sale lands: both legs at dust.
    w.spot = 0;
    w.advance();
    let (p3, b3) = (w.perp(), w.spot());
    match s.settle(NOW + 20, &p3, &b3) {
        Ok(Outcome::Flattened { payout, .. }) => assert_eq!(payout.amount, 2 * NEAR),
        other => panic!("{other:?}"),
    }
    assert_eq!(s.mode, Mode::Flattened);
}

#[test]
fn empty_pool_opens_nothing() {
    let c = strategy(policy()).config;
    let mut s = Strategy::new(c, NEAR / 2).unwrap();
    let mut w = World::hedged();
    w.szi = -6 * ETH / 10;
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::RewardPoolEmpty));
}

#[test]
fn policy_tolerance_must_cover_a_lot() {
    let mut p = policy();
    p.tolerance = 9_999;
    let c = Config { policy: p, ..strategy(policy()).config };
    assert!(matches!(Strategy::new(c, NEAR), Err(Error::BadPolicy(_))));
}

#[test]
fn plans_around_mark_and_charges_the_basis() {
    // Oracle 3000, mark 2950: 1.67% basis, under the 2% cap. The limit sits half a band under the mark.
    let (mut s, mut w) = broken();
    w.mark_raw = 295_000;
    let (p, b) = (w.perp(), w.spot());
    let o = sign(s.open_repair(NOW, "agent.a", &p, &b));
    assert_eq!(o.limit_px, 293_530_000_000, "2950 x 0.995 = 2935.25, rounded up to 5 significant figures");
    assert_eq!(s.job.as_ref().unwrap().loss_used_usd6, 32_640_000, "0.4 ETH x 3000 x (100 + 5 + 167) bp = 32.64 USD");
}

#[test]
fn dislocated_market_plans_nothing() {
    let (mut s, mut w) = broken();
    w.mark_raw = 290_000; // 3.33% under the oracle
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &p, &b), Err(Error::MarketDislocated));

    // Mid-job: the attempt failed and the market then dislocated. The job ends unpaid, not frozen.
    let (mut s, mut w) = broken();
    let (p, b) = (w.perp(), w.spot());
    sign(s.open_repair(NOW, "agent.a", &p, &b));
    w.relay();
    w.advance();
    w.mark_raw = 290_000;
    let (p2, b2) = (w.perp(), w.spot());
    assert!(matches!(s.settle(w.ts, &p2, &b2), Ok(Outcome::Voided { ref reason, .. }) if reason == "market-dislocated"));
    assert_eq!(s.mode, Mode::Active);
}


// ---------- the mandate and the manager-proof exit ----------

const INVESTOR: u8 = 0x77;

/// A directional mandate: no hedge rule, an AI manager capped at 1x, a 59 USD equity floor, and an
/// exit that sends the spot leg to the investor. Starting equity: 30 USD perp + 0.01 ETH at 3000.
fn mandate() -> (Strategy, World) {
    let mut p = policy();
    p.hedge = false;
    p.max_leverage_bp = 10_000;
    p.equity_floor_usd6 = 59_000_000;
    p.spot_gas = 60_000;
    p.spot_max_fee_wei = 50_000_000;
    p.spot_priority_fee_wei = 1_000_000;
    let mut c = strategy(p).config;
    c.manager = Some("ai.testnet".into());
    c.investor = Some(addr(INVESTOR));
    let s = Strategy::new(c, 10 * NEAR).unwrap();
    let mut w = World::hedged();
    w.szi = 0;
    w.entry = 0;
    w.spot = WEI / 100;
    (s, w)
}

fn propose(s: &mut Strategy, w: &mut World, who: &str, is_buy: bool, sz: u64, px: u64) -> Result<Outcome, Error> {
    let (p, b) = (w.perp(), w.spot());
    s.propose(w.ts, who, &p, &b, is_buy, sz, px)
}

#[test]
fn only_the_manager_proposes_and_only_within_the_mandate() {
    let (mut s, mut w) = mandate();
    assert_eq!(propose(&mut s, &mut w, "someone.testnet", false, 1_000_000, 2985 * 100_000_000), Err(Error::Mandate("not-the-manager")));
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2900 * 100_000_000), Err(Error::Mandate("price-outside-band")));
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", false, 1_000_001, 2985 * 100_000_000), Err(Error::Mandate("size")));

    // 0.01 ETH short = 30 USD notional against 60 USD equity: 0.5x, within 1x.
    let o = sign(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2985 * 100_000_000));
    assert_eq!((o.nonce, o.sz, o.reduce_only), (0, 1_000_000, false));

    // Nothing else is signed while that order can still execute.
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2985 * 100_000_000), Err(Error::AttemptNotResolved));

    w.relay();
    w.fill(-ETH / 100, 2_999_000_000);
    // Another 0.01 short: 60 USD notional against 60 USD equity is 1x... and 0.02 more would be 1.5x.
    w.ts += 1;
    let o2 = sign(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2985 * 100_000_000));
    assert_eq!(o2.nonce, 1);
    w.relay();
    w.fill(-ETH / 100, 2_999_000_000);
    w.ts += 1;
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2985 * 100_000_000), Err(Error::Mandate("leverage")));
    // Cutting exposure is always allowed, and is reduce-only.
    let o3 = sign(propose(&mut s, &mut w, "ai.testnet", true, 1_000_000, 3015 * 100_000_000));
    assert!(o3.reduce_only);
}

#[test]
fn below_the_floor_anyone_exits_both_legs_to_the_investor_and_is_paid_once() {
    let (mut s, mut w) = mandate();
    let o = sign(propose(&mut s, &mut w, "ai.testnet", false, 1_000_000, 2985 * 100_000_000));
    w.relay();
    w.fill(-ETH / 100, 2_999_000_000);

    // Above the floor nobody may force an exit.
    w.ts += 1;
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_flatten(w.ts, "guardian.testnet", &p, &b), Err(Error::FlattenNotTriggered));

    // The AI's trading lost money: 25 USD perp + 30 USD spot = 55 USD, under the 59 USD floor.
    w.account_value = 25_000_000;
    w.ts += 1;
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", true, 1_000_000, 3015 * 100_000_000), Err(Error::Mandate("equity-below-floor")));
    let (p, b) = (w.perp(), w.spot());
    let (order, exit) = match s.open_flatten(w.ts, "guardian.testnet", &p, &b) {
        Ok(Outcome::Sign { order, spot_exit: Some(exit), .. }) => (order, exit),
        other => panic!("{other:?}"),
    };
    assert!(order.is_buy && order.reduce_only && order.sz == 1_000_000 && order.nonce == o.nonce + 1);
    assert_eq!(exit.tx.to, addr(0x33), "the spot token");
    assert_eq!(exit.tx.nonce, 0);
    assert_eq!(&exit.tx.data[16..36], &[INVESTOR; 20], "transfer recipient is the investor");
    assert_eq!(exit.digest.0, exit.tx.signing_hash());
    assert_eq!(propose(&mut s, &mut w, "ai.testnet", true, 1_000_000, 3015 * 100_000_000), Err(Error::Mandate("strategy-not-active")));

    // Perp closed, spot transfer not landed yet: only the spot transaction is re-issued, same nonce.
    w.relay();
    w.fill(ETH / 100, 0);
    let (p, b) = (w.perp(), w.spot());
    match s.settle(w.ts, &p, &b) {
        Ok(Outcome::SignSpot { spot_exit, .. }) => assert_eq!(spot_exit.tx.nonce, 0),
        other => panic!("{other:?}"),
    }
    assert_eq!(s.payouts.len(), 0, "half an exit pays nothing");

    // Spot moved to the investor: both legs empty, the guardian is paid once.
    w.spot = 0;
    w.advance();
    let (p, b) = (w.perp(), w.spot());
    match s.settle(w.ts, &p, &b) {
        Ok(Outcome::Flattened { payout, .. }) => assert_eq!(payout.agent, "guardian.testnet"),
        other => panic!("{other:?}"),
    }
    assert_eq!(s.spot_nonce, 1);
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.settle(w.ts, &p, &b), Err(Error::NoOpenJob));

    // Then the perp USDC goes to KeelLeg's fixed payout.
    w.ts += 1;
    let (p, b) = (w.perp(), w.spot());
    match s.sweep(w.ts, &p, &b) {
        Ok(Outcome::SignSweep { sweep }) => assert_eq!((sweep.sweep.usd_ntl, sweep.sweep.usdc_wei), (25_000_000, 2_500_000_000)),
        other => panic!("{other:?}"),
    }
    w.ts += 1;
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.sweep(w.ts, &p, &b), Err(Error::AttemptNotResolved));
}

#[test]
fn an_exit_with_a_flat_perp_only_moves_the_spot_leg() {
    let (mut s, mut w) = mandate();
    w.account_value = 20_000_000;
    let (p, b) = (w.perp(), w.spot());
    match s.open_flatten(w.ts, "guardian.testnet", &p, &b) {
        Ok(Outcome::SignSpot { spot_exit, .. }) => assert_eq!(spot_exit.tx.nonce, 0),
        other => panic!("{other:?}"),
    }
}

#[test]
fn a_directional_mandate_has_no_hedge_repair() {
    let (mut s, mut w) = mandate();
    let (p, b) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(w.ts, "agent.a", &p, &b), Err(Error::Mandate("no-hedge-rule")));
}

#[test]
fn perp_snapshots_must_be_younger_than_spot_evidence() {
    let mut p = policy();
    p.max_evidence_age_s = 3_600;
    p.max_perp_age_s = 120;
    let mut s = strategy(p);
    let mut w = World::hedged();
    w.szi = -6 * ETH / 10;
    // A 20-minute-old snapshot (the Base wait) is refused for planning...
    w.ts = NOW - 1_200;
    let (pl, bl) = (w.perp(), w.spot());
    assert_eq!(s.open_repair(NOW, "agent.a", &pl, &bl), Err(Error::StaleEvidence));
    // ...but 20-minute-old Base evidence with a fresh snapshot is fine.
    let bl = w.spot();
    w.ts = NOW;
    let pl = w.perp();
    assert!(matches!(s.open_repair(NOW, "agent.a", &pl, &bl), Ok(Outcome::Sign { .. })));
}
